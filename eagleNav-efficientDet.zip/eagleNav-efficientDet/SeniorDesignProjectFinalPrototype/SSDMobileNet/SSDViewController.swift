
//
//  SSDDepthViewController.swift
//  SSDMobileNet
//
//  A drop-in replacement for SSDViewController that uses ARKit + LiDAR depth
//  to estimate distance and physical size, recognizes multiple objects,
//  and provides spoken feedback (spatialized when possible).
//
//  iOS 15+ recommended. Requires a LiDAR-capable device for depth output.
//  Falls back gracefully (no distance/size) on devices without sceneDepth.
//
//  To use: set your storyboard's initial view controller's class to `SSDDepthViewController`
//  or instantiate/present it programmatically.
//

import UIKit
import CoreML
import Vision
import ARKit
import AVFoundation
import Accelerate
import ImageIO

final class SSDDepthViewController: UIViewController, ARSessionDelegate {

    // MARK: - UI
    @IBOutlet weak var cameraView: UIView!  // hook to your storyboard's camera view

    private let sceneView = ARSCNView(frame: .zero)
    private var screenWidth: CGFloat = 0
    private var screenHeight: CGFloat = 0

    // MARK: - Drawing (reuses BoundingBox.swift from project)
    private let numBoxes = 100
    private var boundingBoxes: [BoundingBox] = []

    // MARK: - Inference
    private let ssdPostProcessor = SSDPostProcessor(numAnchors: 1917, numClasses: 90, threshold: 0.05)
    private var visionModel: VNCoreMLModel?
    private var vnRequest: VNCoreMLRequest?
    private let semaphore = DispatchSemaphore(value: 1)
    private var lastExecution = Date()

    // MARK: - Audio
    private let announcer = SpatialAnnouncer()
    public var enableAnnouncements = true
    public var overfitMode: OverfitMode = .clampToRange

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setupSceneView()
        setupBoxes()
        setupModel()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        screenWidth = view.bounds.width
        screenHeight = view.bounds.height
        sceneView.frame = cameraView?.bounds ?? view.bounds
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startARSession()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }

    private func setupSceneView() {
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        if let container = cameraView {
            container.addSubview(sceneView)
            sceneView.frame = container.bounds
            sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        } else {
            view.addSubview(sceneView)
            sceneView.frame = view.bounds
            sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        }
        sceneView.automaticallyUpdatesLighting = false
        sceneView.debugOptions = []
        sceneView.contentScaleFactor = UIScreen.main.scale
        sceneView.session.delegate = self
    }

    private func setupBoxes() {
        boundingBoxes = (0..<numBoxes).map { _ in BoundingBox() }
        for b in boundingBoxes {
            b.addToLayer(sceneView.layer)
        }
    }

    private func setupModel() {
        if #available(iOS 12.0, *) {
            do {
                let core = try ssd_mobilenet_feature_extractor(configuration: MLModelConfiguration()).model
                visionModel = try VNCoreMLModel(for: core)
            } catch {
                fatalError("Can't load Core ML model: \(error)")
            }
        } else {
            let core = try! ssd_mobilenet_feature_extractor().model
            visionModel = try! VNCoreMLModel(for: core)
        }

        guard let model = visionModel else { fatalError("No VNCoreMLModel") }

        let req = VNCoreMLRequest(model: model) { [weak self] req, err in
            guard let self = self else { return }
            self.handleVNResults(request: req, error: err)
        }
        req.imageCropAndScaleOption = .centerCrop
        self.vnRequest = req
    }

    private func startARSession() {
        guard ARWorldTrackingConfiguration.isSupported else {
            assertionFailure("ARKit world tracking not supported on this device.")
            return
        }
        let config = ARWorldTrackingConfiguration()
        if ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) {
            config.frameSemantics.insert(.sceneDepth)
            config.frameSemantics.insert(.smoothedSceneDepth)
        }
        sceneView.session.run(config, options: [.resetTracking, .removeExistingAnchors])
    }

    // MARK: - ARSessionDelegate
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        guard let request = self.vnRequest else { return }

        // Ensure only one in-flight request
        guard semaphore.wait(timeout: .now()) == .success else { return }
        defer { semaphore.signal() }

        // Orientation
        let exif = self.exifOrientation(for: UIDevice.current.orientation)
        let cgOrientation = CGImagePropertyOrientation(rawValue: UInt32(exif.rawValue)) ?? .right

        // Camera intrinsics for Vision (optional but helps geometry-sensitive models)
        let intrinsicsData = withUnsafeBytes(of: frame.camera.intrinsics) { Data($0) }
        let options: [VNImageOption: Any] = [.cameraIntrinsics: intrinsicsData]

        let handler = VNImageRequestHandler(cvPixelBuffer: frame.capturedImage,
                                            orientation: cgOrientation,
                                            options: options)
        do {
            try handler.perform([request])
        } catch {
            NSLog("VN perform error: \(error.localizedDescription)")
        }
    }

    // MARK: - Results handling
    private func handleVNResults(request: VNRequest, error: Error?) {
        // FPS label logic (optional)
        let now = Date()
        let dt = now.timeIntervalSince(lastExecution)
        lastExecution = now

        guard
            let results = request.results as? [VNCoreMLFeatureValueObservation],
            results.count == 2,
            let boxPreds = results[1].featureValue.multiArrayValue,
            let classPreds = results[0].featureValue.multiArrayValue
        else { return }

        let predictions = ssdPostProcessor.postprocess(boxPredictions: boxPreds, classPredictions: classPreds)

        // Draw and announce on main thread
        DispatchQueue.main.async {
            self.drawBoxes(predictions: predictions)
            if self.enableAnnouncements {
                self.announce(predictions: predictions)
            }
        }
    }

    // MARK: - Drawing
    private func drawBoxes(predictions: [Prediction]) {
        guard screenWidth > 0, screenHeight > 0 else { return }

        // View mapping: center-cropped square with vertical letterboxing (portrait)
        let side = screenWidth
        let yOffset = (screenHeight - screenWidth) / 2

        // Clear exceeding boxes
        for i in 0..<numBoxes { boundingBoxes[i].hide() }

        let maxShown = min(predictions.count, numBoxes)
        for (idx, p) in predictions.prefix(maxShown).enumerated() {
            guard let classes = ssdPostProcessor.classNames,
                  p.detectedClass >= 0, p.detectedClass < classes.count else { continue }

            let labelString = classes[p.detectedClass]
            let score = sigmoid(p.score)

            // Compute rect in view space
            let rect300 = p.finalPrediction.toCGRect()
            let rectView = CGRect(
                x: rect300.origin.x * (side/300.0),
                y: rect300.origin.y * (side/300.0) + yOffset,
                width: rect300.width * (side/300.0),
                height: rect300.height * (side/300.0)
            )

            // If we have an ARFrame, estimate distance & meter sizes.
            var dimText = ""
            if let frame = sceneView.session.currentFrame,
               ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) {
                let imageRect = DepthAndSizeEstimator.imageRectForPrediction(rect300, imageResolution: CGSize(width: CGFloat(frame.camera.imageResolution.width), height: CGFloat(frame.camera.imageResolution.height)))
                let estimate = DepthAndSizeEstimator.estimate(
                    rect300: rect300,
                    label: labelString,
                    frame: frame,
                    overfit: overfitMode
                )
                if let d = estimate.distanceM, let w = estimate.widthM, let h = estimate.heightM {
                    dimText = String(format: "  %.1fm  %.0fx%.0fcm", d, w*100.0, h*100.0)
                } else if let d = estimate.distanceM {
                    dimText = String(format: "  %.1fm", d)
                }
            }

            let display = String(format: "%.0f%% - %@%@", score*100.0, labelString, dimText)

            boundingBoxes[idx].show(frame: rectView, label: display, color: .red, textColor: .black)
        }
    }

    // MARK: - Announcements
    private func announce(predictions: [Prediction]) {
        guard let frame = sceneView.session.currentFrame else { return }
        let side = screenWidth
        let yOffset = (screenHeight - screenWidth) / 2

        // Announce top-k by confidence
        for p in predictions.prefix(3) {
            guard let classes = ssdPostProcessor.classNames,
                  p.detectedClass >= 0, p.detectedClass < classes.count else { continue }
            let label = classes[p.detectedClass]
            let rect300 = p.finalPrediction.toCGRect()
            let centerViewX = (rect300.midX * (side/300.0)) / side
            // Depth
            var distance: Float? = nil
            if ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) {
                let estimate = DepthAndSizeEstimator.estimate(rect300: rect300,
                                                              label: label,
                                                              frame: frame,
                                                              overfit: overfitMode)
                distance = estimate.distanceM
            }
            let sideWord: String = (centerViewX < 0.33) ? "left" : ((centerViewX > 0.66) ? "right" : "center")
            var parts: [String] = [label, sideWord]
            if let d = distance { parts.append(String(format: "%.1f meters", d)) }
            let sentence = parts.joined(separator: ", ")
            announcer.speak(.init(text: sentence, xNormalized: CGFloat(centerViewX), distanceM: distance))
        }
    }

    // MARK: - Helpers
    private func sigmoid(_ x: Double) -> Double {
        return 1.0 / (1.0 + exp(-x))
    }

    // Keep consistent with the project’s existing EXIF mapping
    private enum EXIFOrientation: Int32 {
        case topLeft = 1, topRight, bottomRight, bottomLeft, leftTop, rightTop, rightBottom, leftBottom
    }

    private func exifOrientation(for deviceOrientation: UIDeviceOrientation) -> EXIFOrientation {
        switch deviceOrientation {
        case .landscapeRight:       return .bottomRight
        case .landscapeLeft:        return .topLeft
        case .portrait:             return .rightTop
        case .portraitUpsideDown:   return .leftBottom
        case .faceUp, .faceDown:    return .rightTop
        default:                    return .rightTop
        }
    }
}

